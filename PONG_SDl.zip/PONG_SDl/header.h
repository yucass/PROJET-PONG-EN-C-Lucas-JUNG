#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED



#endif // HEADER_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <stdbool.h>
#include <sys/time.h>
#include <string.h>
#include <windows.h>
#include <SDL2/SDL_ttf.h>

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 780

typedef struct game{
     SDL_Window *g_pWindow;
     SDL_Renderer *g_pRenderer;
     SDL_Texture *g_ptexture;
     SDL_Surface *g_psurface;
}game;

typedef struct gameState{
    int g_bRunning;
}gameState;

typedef struct coordonnees{

    double x;
    double y;

}coordonnees;

typedef struct font{

    TTF_Font *g_font;

}font;

//prototypes
int init(char *title, int xpos,int ypos,int width, int height,int flags,game *myGame, font *mFont);
void destroy(game *myGame, font *mFont);
void handleEvents(gameState *state,coordonnees *dep,coordonnees *dep2, coordonnees *moveball);
void delay(unsigned int frameLimit);

void render(game *myGame, font *mFont);
void renderTexture(game *myGame,coordonnees *dep,coordonnees *dep2, coordonnees *moveball, font *mFont );
void mouvementball (coordonnees *dep,coordonnees *dep2, coordonnees *moveball, int directionx, int directiony);
